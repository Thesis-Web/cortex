import json, os, re, glob, sys, datetime, collections

KW = re.compile(r"cortex|blink|hydrat|drift|hallucinat|invention|wake|close_out|closeout|teleprompter|jev|typesafe|on rail|scope", re.I)
SKIP_CONTAINS = ["<system-reminder>", "<command-name>", "<local-command", "<environment_context>", "<INSTRUCTIONS>", "<user_instructions>", "<permissions instructions>", "<recommended_plugins>"]
SKIP_PREFIX = ["<", "## Page contract", "This session is being continued from a previous conversation", "[Request interrupted"]

entries = []   # (ts, basename, text, src)
skill_raw = []  # (ts, basename, fulltext, skillname)
SK_RE = re.compile(r"^Base directory for this skill: (\S+)")
stats = collections.Counter()
files_scanned = 0

def ok_text(t):
    if not isinstance(t, str): return False
    s = t.strip()
    if not s: return False
    for p in SKIP_PREFIX:
        if s.startswith(p): return False
    for c in SKIP_CONTAINS:
        if c in s: return False
    return bool(KW.search(s))

def claude_text(content):
    if isinstance(content, str): return content
    if isinstance(content, list):
        parts = [i.get("text","") for i in content if isinstance(i, dict) and i.get("type") == "text"]
        return "\n".join(p for p in parts if p)
    return ""

# --- Claude Code
cc_files = [f for f in glob.glob("/home/exnulla/.claude/projects/*/*.jsonl")]
for f in cc_files:
    try:
        with open(f, "rb") as fh:
            raw = fh.read()
    except Exception as e:
        stats["cc_read_err"] += 1; continue
    if b"ortex" not in raw and not re.search(rb"(?i)cortex", raw):
        # still scan: keywords other than cortex matter, but brief says pick files via grep cortex
        continue
    files_scanned += 1
    for line in raw.splitlines():
        if b'"type":"user"' not in line: continue
        try: o = json.loads(line)
        except Exception: stats["cc_json_err"] += 1; continue
        if o.get("type") != "user": continue
        if o.get("isSidechain"): stats["cc_skip_sidechain"] += 1; continue
        if o.get("promptSource") == "sdk" or o.get("entrypoint") == "sdk-cli": stats["cc_skip_sdk"] += 1; continue
        msg = o.get("message") or {}
        t = claude_text(msg.get("content"))
        m = SK_RE.match(t.strip()) if isinstance(t, str) else None
        if m:
            skill_raw.append((o.get("timestamp",""), os.path.basename(f), t, m.group(1))); continue
        if not ok_text(t): continue
        entries.append((o.get("timestamp",""), os.path.basename(f), t.strip(), "cc"))

# owner-typed remainder of skill expansions
def owner_part(t, siblings):
    for mk in ["\nARGUMENTS:", "Apply the user's optional focus or mode:"]:
        i = t.rfind(mk)
        if i >= 0:
            r = t[i+len(mk):].strip()
            if r: return r
    best = []
    for u in siblings:
        if u is t: continue
        n = min(len(t), len(u)); k = 0
        while k < n and t[k] == u[k]: k += 1
        best.append(k)
    for k in sorted(best, reverse=True):
        r = t[k:].strip()
        if r and len(r) < 3000 and k >= 0.8*len(t):
            stats["skill_fallback_used"] += 1
            return r
        if r: break
    return ""
groups = collections.defaultdict(list)
for ts, bn, t, sk in skill_raw: groups[sk].append(t)
for ts, bn, t, sk in skill_raw:
    r = owner_part(t, groups[sk])
    stats["skill_turns"] += 1
    if not r or not ok_text(r): stats["skill_turns_no_owner_kw"] += 1; continue
    entries.append((ts, bn + "  (owner text typed after /" + sk.rstrip("/").split("/")[-1] + ")", r, "cc"))

# --- Codex
cx_files = glob.glob("/home/exnulla/.codex/sessions/**/*.jsonl", recursive=True)
for f in cx_files:
    try:
        with open(f, "rb") as fh: raw = fh.read()
    except Exception: stats["cx_read_err"] += 1; continue
    if not re.search(rb"(?i)cortex", raw): continue
    files_scanned += 1
    headless = False
    for line in raw.splitlines():
        try: o = json.loads(line)
        except Exception: stats["cx_json_err"] += 1; continue
        if o.get("type") == "session_meta":
            p = o.get("payload") or {}
            if p.get("source") == "exec" or "exec" in str(p.get("originator","")):
                headless = True
            break
    if headless: stats["cx_skip_headless_files"] += 1; files_scanned -= 1; continue
    for line in raw.splitlines():
        if b'"role":"user"' not in line: continue
        try: o = json.loads(line)
        except Exception: continue
        if o.get("type") != "response_item": continue
        p = o.get("payload") or {}
        if p.get("type") != "message" or p.get("role") != "user": continue
        parts = [c.get("text","") for c in (p.get("content") or []) if isinstance(c, dict) and c.get("type") in ("input_text","text")]
        t = "\n".join(x for x in parts if x)
        if not ok_text(t): continue
        entries.append((o.get("timestamp",""), os.path.basename(f), t.strip(), "cx"))

# --- paste cache
for f in glob.glob("/home/exnulla/.claude/paste-cache/*.txt"):
    try:
        with open(f, "rb") as fh: raw = fh.read()
    except Exception: continue
    if not re.search(rb"(?i)cortex", raw): continue
    files_scanned += 1
    t = raw.decode("utf-8", "replace").strip()
    ts = datetime.datetime.utcfromtimestamp(os.path.getmtime(f)).strftime("%Y-%m-%dT%H:%M:%SZ")
    entries.append((ts, "paste-cache/" + os.path.basename(f), t, "paste"))

# dedupe exact repeats (whitespace-normalized), keep earliest
seen = set(); out = []
entries.sort(key=lambda e: e[0])
for ts, bn, t, src in entries:
    k = re.sub(r"\s+", " ", t)
    if k in seen: stats["dedup"] += 1; continue
    seen.add(k); out.append((ts, bn, t, src))

by_month = collections.Counter(e[0][:7] for e in out)
by_src = collections.Counter(e[3] for e in out)

ncc = sum(1 for f in cc_files if re.search(rb'(?i)cortex', open(f,'rb').read()))
now = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
hdr = [
 "# CORTEX - owner's own words, verbatim (Claude Code + Codex transcripts + paste cache on this machine)",
 f"Made {now} by a read-only extractor: files picked by case-insensitive grep for 'cortex', then every main-thread user turn (Claude Code: type=user, not sidechain, not sdk-originated, no system/hook/compaction injections; Codex: interactive sessions only, role=user; paste-cache files whole, dated by mtime) containing any of: cortex, blink, hydrat, drift, hallucinat, invention, wake, close_out, closeout, teleprompter, jev, typesafe, 'on rail', scope.",
 f"Files scanned: {files_scanned} parsed (Claude Code {ncc}, Codex interactive {files_scanned-ncc-by_src['paste']}, paste-cache {by_src['paste']}); picked by grep from {len(cc_files)} Claude Code + {len(cx_files)} Codex transcripts + {len(glob.glob('/home/exnulla/.claude/paste-cache/*.txt'))} pastes.",
 f"Messages: {len(out)} (Claude Code {by_src['cc']}, Codex {by_src['cx']}, pastes {by_src['paste']}); {stats['dedup']} exact repeats dropped; {stats['cc_skip_sdk']} sdk-courier turns excluded as not owner-written; {stats['cx_skip_headless_files']} headless (codex_exec) Codex files excluded as machine-written; of {stats['skill_turns']} /skill expansion turns only the owner-typed remainder is kept (skill body is harness-injected), {stats['skill_turns_no_owner_kw']} had no owner text matching the keywords.",
 "Time box: 25 min wall clock from 2026-11-02T20:48:58Z; nothing paraphrased, nothing cut from inside a message; sorted by date ascending.",
 "", ""]
body = []
for ts, bn, t, src in out:
    body.append(f"### {ts}  {bn}\n{t}\n")
tail = ["## Counts by month"] + [f"- {m}: {c}" for m, c in sorted(by_month.items())]
doc = "\n".join(hdr) + "\n".join(body) + "\n" + "\n".join(tail) + "\n"

for path in ["/mnt/c/Users/AdLibitumVita/Downloads/CORTEX-OWNER-WORDS-2026-11-02.md",
             "/tmp/claude-1000/-home-exnulla/3fc1ea58-5d0b-4402-a7b1-c83b0461e0e4/scratchpad/CORTEX-OWNER-WORDS-2026-11-02.md"]:
    with open(path, "w", encoding="utf-8") as fh: fh.write(doc)

print("files_scanned", files_scanned, "entries", len(out), dict(stats), dict(by_src))
print("range", out[0][0] if out else None, out[-1][0] if out else None)
for m,c in sorted(by_month.items()): print(m, c)
# index for my own review: date, src, len, first 100 chars
with open("/tmp/claude-1000/-home-exnulla/3fc1ea58-5d0b-4402-a7b1-c83b0461e0e4/scratchpad/extract/index.tsv","w") as fh:
    for ts,bn,t,src in out:
        fh.write(f"{ts}\t{src}\t{len(t)}\t{t[:140].replace(chr(10),' ')}\n")

dens = []
for ts,bn,t,src in out:
    hits = len(KW.findall(t)); words = max(1,len(t.split()))
    dens.append((hits, hits/words, ts, src, len(t), t[:110].replace("\n"," ")))
print("== top by keyword hits")
for d in sorted(dens, reverse=True)[:30]: print(d[0], round(d[1],3), d[2], d[3], d[4], d[5])
